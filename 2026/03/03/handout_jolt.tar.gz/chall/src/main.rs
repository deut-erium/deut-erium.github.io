use std::path::PathBuf;
use std::io::Read;
use jolt_sdk::{JoltProof, Serializable, host::Program};

fn print_hex(bytes: &[u8]) {
    println!("{}", bytes.iter().map(|b| format!("{:02x}", b)).collect::<String>());
}

pub fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt::init();

    let target_dir = "/tmp/jolt-guest-targets";
    let elf_path = format!("{target_dir}/guest-flt/riscv64imac-unknown-none-elf/release/guest");

    if !std::path::Path::new(&elf_path).exists() {
        // first time setup, compile guest and create urs
        let mut program = guest::compile_flt(&target_dir);
        let _ = guest::preprocess_prover_flt(&mut program);

        println!("setup done, exiting");
        return Ok(());
    }

    let mut program = Program::new("guest");
    program.elf = Some(elf_path.clone().into());

    print_hex(&std::fs::read(elf_path)?);
    print_hex(&std::fs::read("./dory_urs_24_variables.urs")?);

    let mut lines = std::io::stdin().lines();
    let a: u64 = lines.next().expect("EOF")?.parse()?;
    let b: u64 = lines.next().expect("EOF")?.parse()?;
    let c: u64 = lines.next().expect("EOF")?.parse()?;
    let proof_hex = lines.next().expect("EOF")?;
    let proof_bytes = (0..proof_hex.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&proof_hex[i..i + 2], 16))
        .collect::<Result<Vec<u8>, _>>()?;
    let proof = JoltProof::deserialize_from_bytes(&proof_bytes)?;

    let prover_preprocessing = guest::preprocess_prover_flt(&mut program);
    let verifier_preprocessing = guest::verifier_preprocessing_from_prover_flt(&prover_preprocessing);

    let verify_flt = guest::build_verifier_flt(verifier_preprocessing);

    let output = Some(true); // please provide a counter example of flt
    let panic = false;
    if verify_flt(a, b, c, output, panic, proof) {
        println!("{}", std::fs::read_to_string("/flag.txt")?);
    } else {
        println!("invalid proof");
    }
    Ok(())
}
